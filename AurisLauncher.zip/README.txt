AURIS LAUNCHER - cómo compilar desde el móvil (sin PC)

1. Crea una cuenta en github.com y un repositorio nuevo (privado o público).
2. Sube TODO el contenido de esta carpeta (usa "Add file > Upload files"; la carpeta
   .github/workflows/build.yml es la que compila la APK).
3. Ve a la pestaña "Actions" > "Build APK" > espera ~3-5 min.
4. Entra en la ejecución terminada y descarga el artefacto "AurisLauncher-apk".
5. Pasa app-debug.apk a la Kojima (USB/pendrive) e instálala.
6. Al pulsar Inicio, elige "Auris Launcher" > "Siempre".
7. Toca "Activar música" y concede acceso a notificaciones; concede ubicación para la velocidad.

Foto del Auris: guarda auris.png en app/src/main/res/drawable/ y en activity_main.xml
agrega android:src="@drawable/auris" al ImageView @+id/imgCar.
