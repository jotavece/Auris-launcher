package com.auris.launcher

import android.service.notification.NotificationListenerService

// Solo existe para que Android nos dé permiso de leer las sesiones multimedia (Spotify, etc.)
class MediaListener : NotificationListenerService()
