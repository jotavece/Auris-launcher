package com.auris.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null

    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvGps: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnPlay: ImageButton

    private val mapsPkgs = arrayOf("com.google.android.apps.maps", "com.waze")

    private val tick = object : Runnable {
        override fun run() {
            updateMedia()
            ui.postDelayed(this, 1000)
        }
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val kmh = if (loc.hasSpeed()) (loc.speed * 3.6f).toInt() else 0
            tvSpeed.text = (if (kmh < 2) 0 else kmh).toString()
            tvGps.text = "Velocidad GPS"
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {
            tvGps.text = "GPS apagado"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvGps = findViewById(R.id.tvGps)
        progress = findViewById(R.id.progress)
        btnPlay = findViewById(R.id.btnPlay)

        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener {
            controller?.transportControls?.skipToPrevious()
        }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener {
            controller?.transportControls?.skipToNext()
        }
        btnPlay.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c.transportControls.pause()
            } else {
                c.transportControls.play()
            }
        }
        tvTitle.setOnClickListener {
            if (!listenerEnabled()) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        findViewById<View>(R.id.btnConnectAA).setOnClickListener { launch("com.google.android.projection.gearhead") }
        findViewById<View>(R.id.btnMaps).setOnClickListener { launch("com.google.android.apps.maps") }
        findViewById<View>(R.id.btnWaze).setOnClickListener { launch("com.waze") }

        buildBottomBar()

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    private fun buildBottomBar() {
        val bar = findViewById<LinearLayout>(R.id.bottomBar)
        data class Item(val icon: String, val label: String, val action: () -> Unit)
        val items = listOf(
            Item("⌂", "Inicio") { },
            Item("♫", "Spotify") { launch("com.spotify.music") },
            Item("✆", "Teléfono") { startActivity(Intent(Intent.ACTION_DIAL)) },
            Item("▲", "Android Auto") { launch("com.google.android.projection.gearhead") },
            Item("➤", "Navegación") { launch(*mapsPkgs) },
            Item("▦", "Apps") { showApps() },
            Item("⚙", "Ajustes") { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        )
        for (it in items) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { _ -> it.action() }
            }
            cell.addView(TextView(this).apply {
                text = it.icon
                textSize = 24f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
            })
            cell.addView(TextView(this).apply {
                text = it.label
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(0xFFCFE0FF.toInt())
            })
            bar.addView(cell)
        }
    }

    private fun launch(vararg pkgs: String) {
        for (p in pkgs) {
            val i = packageManager.getLaunchIntentForPackage(p)
            if (i != null) {
                startActivity(i)
                return
            }
        }
        Toast.makeText(this, "App no instalada", Toast.LENGTH_SHORT).show()
    }

    private fun showApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Apps")
            .setItems(names) { _, i -> launch(apps[i].activityInfo.packageName) }
            .show()
    }

    // ---------- Multimedia ----------
    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun refreshController() {
        controller = try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
            list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        } catch (e: SecurityException) {
            null
        }
    }

    private fun updateMedia() {
        if (!listenerEnabled()) {
            tvTitle.text = "Activar música"
            tvArtist.text = "Toca aquí y permite el acceso"
            return
        }
        refreshController()
        val c = controller
        if (c == null) {
            tvTitle.text = "Sin reproducción"
            tvArtist.text = "Abre Spotify"
            progress.progress = 0
            btnPlay.setImageResource(android.R.drawable.ic_media_play)
            return
        }
        val md = c.metadata
        tvTitle.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Reproduciendo"
        tvArtist.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""

        val ps = c.playbackState
        val playing = ps?.state == PlaybackState.STATE_PLAYING
        btnPlay.setImageResource(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)

        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (ps != null && dur > 0) {
            var pos = ps.position
            if (playing) {
                pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
            }
            progress.progress = (pos.coerceIn(0, dur) * 1000 / dur).toInt()
        } else {
            progress.progress = 0
        }
    }

    // ---------- GPS ----------
    private fun startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        } catch (e: Exception) {
            tvGps.text = "GPS no disponible"
        }
    }

    private fun stopLocation() {
        (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locListener)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        startLocation()
    }

    // ---------- Ciclo de vida ----------
    override fun onResume() {
        super.onResume()
        ui.post(tick)
        startLocation()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        stopLocation()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Como launcher, "atrás" no debe cerrar la pantalla de inicio
    }
}
